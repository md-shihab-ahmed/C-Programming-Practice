#include <stdio.h>

int main() {
char ch;
printf("Enter letter");
scanf("%c",&ch);
if(ch=='a' || ch=='A' ||ch=='e' || ch=='E'||ch=='i' || ch=='I'||ch=='O' || ch=='o'||ch=='u' || ch=='U' )
printf("Vowel");
else
printf("Consonant");
    return 0;
}