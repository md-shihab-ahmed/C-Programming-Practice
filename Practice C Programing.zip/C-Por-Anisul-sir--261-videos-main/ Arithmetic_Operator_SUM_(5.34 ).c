// 1st program to add two numbers using arithmetic operator SUM
#include <stdio.h>

int main() {
int num1,num2,sum;
printf("Enter two Numbers:");
scanf("%d %d", &num1,&num2);
sum = num1+num2;
printf(" The sum is %d",sum);
    return 0;
}